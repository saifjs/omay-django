from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User

class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    phone_number = forms.CharField(required=False)

    class Meta:
        model = User
        fields = ['username', 'email', 'phone_number', 'password1', 'password2']

class ContactForm(forms.Form):
    name = forms.CharField(max_length=100)
    email = forms.EmailField()
    message = forms.CharField(widget=forms.Textarea)

    def clean_name(self):
        name = self.cleaned_data.get('name')
        # Add any custom validation logic for the name field if needed
        return name

    def clean_email(self):
        email = self.cleaned_data.get('email')
        # Add any custom validation logic for the email field if needed
        return email

    def clean_message(self):
        message = self.cleaned_data.get('message')
        # Add any custom validation logic for the message field if needed
        return message
