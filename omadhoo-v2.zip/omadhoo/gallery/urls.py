from django.urls import path
from .views import GalleryView, upload_image

urlpatterns = [
    path('', GalleryView.as_view(), name='gallery'),
    path('upload/', upload_image, name='upload_image'),
]
