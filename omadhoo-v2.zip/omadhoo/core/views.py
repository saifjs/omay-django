from django.shortcuts import render, redirect
from .forms import CustomUserCreationForm, ContactForm
from django.core.mail import send_mail

# Create your views here.

def home(request):
    return render(request, 'core/home.html')

def about(request):
    return render(request, 'core/about.html')

def contact_view(request):
    if request.method == 'POST':
        form = ContactForm(request.POST)
        if form.is_valid():
            name = form.cleaned_data.get('name')
            email = form.cleaned_data.get('email')
            message = form.cleaned_data.get('message')

            # Perform any necessary actions with the validated form data
            # For example, save the message to a database or send an email

            # Send an email notification
            subject = 'New Contact Message'
            message_body = f"Name: {name}\nEmail: {email}\nMessage: {message}"
            sender_email = '{email}'
            recipient_email = 'noreply@omadhoo.com'

            send_mail(subject, message_body, sender_email, [recipient_email])

            # Render a success message or redirect the user to another page
            return render(request, 'core/contact_success.html')
    else:
        form = ContactForm()

    return render(request, 'core/contact.html', {'form': form})


def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.email = form.cleaned_data['email']
            user.phone_number = form.cleaned_data['phone_number']
            user.save()
            return redirect('login')
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/register.html', {'form': form})
