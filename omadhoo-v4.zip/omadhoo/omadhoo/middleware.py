from django.shortcuts import redirect
from django.contrib.admin.views.decorators import staff_member_required

class RestrictAdminMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.path.startswith('/admin/'):
            return redirect('home')  # Redirect to the home page or any other desired URL

        return self.get_response(request)

@staff_member_required
def redirect_admin(request):
    return redirect('/admin/')
