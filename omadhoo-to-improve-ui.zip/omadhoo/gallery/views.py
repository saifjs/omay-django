from django.shortcuts import render, redirect
from django.views.generic import ListView
from .models import Image
from .forms import ImageUploadForm
from django.contrib.auth.decorators import login_required

# Create your views here.

class GalleryView(ListView):
    model = Image
    template_name = 'gallery/gallery.html'
    context_object_name = 'images'

@login_required(login_url='login')  # Specify the login URL
def upload_image(request):
    if request.method == 'POST':
        form = ImageUploadForm(request.POST, request.FILES)
        if form.is_valid():
            image = form.save(commit=False)
            image.user = request.user
            image.save()
            return redirect('gallery')
    else:
        form = ImageUploadForm()
    return render(request, 'gallery/upload_image.html', {'form': form})
